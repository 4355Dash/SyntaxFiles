<Syntax.readme>

This release includes only the UI and some features of the SYNTAX executor. However, execution and injection functionalities are not yet implemented. As a result, errors may occur when attempting to inject or execute.

— ZSimulators